#ifndef TABLE_REC_ITER_H
#define TABLE_REC_ITER_H

using namespace std;

class MyDB_TableRecIter:public virtual MyDB_RecordIterator{

};


#endif
