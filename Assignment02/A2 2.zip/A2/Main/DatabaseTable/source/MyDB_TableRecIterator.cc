#ifndef TABLE_REC_ITER_C
#define TABLE_REC_ITER_C
#include "MyDB_TableRecIterator.h"

using namespace std;





